// contentScript.js
let isSelectingElement = false;

// Function to start the element selection process when the extension icon is clicked.
function startElementSelection() {
  isSelectingElement = true;
  document.body.style.cursor = "crosshair";
  document.addEventListener("click", handleElementClick, true);
}

// Function to handle the click event when the user selects an element.
function handleElementClick(event) {
  event.preventDefault();
  event.stopPropagation();

  if (!isSelectingElement) {
    return;
  }

  document.body.style.cursor = "default";
  document.removeEventListener("click", handleElementClick, true);
  isSelectingElement = false;

  const selectedElement = event.target;

  // Get the "src" attribute from the selected element.
  const srcData = selectedElement.getAttribute("src");

  // Send the "src" data to the popup.
  chrome.runtime.sendMessage({ message: "element_selected", src: srcData });
}

// Listen for messages from the popup script to start the element selection process.
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.message === "start_element_selection") {
    startElementSelection();
  }
});
