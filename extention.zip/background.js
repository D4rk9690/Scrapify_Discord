// background.js
chrome.browserAction.onClicked.addListener(function (tab) {
    chrome.tabs.sendMessage(tab.id, { message: "get_div_data" }, function (response) {
      // Use the extracted data as needed
      if (response && response.data) {
        console.log("Data from div: ", response.data);
      }
    });
  });
  